-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- LS 2013 Framework by Miko 
-- Loader
------------------------------------------------------------*/

LoadFramework = {};
__BASE_DIR__ = '/__frameworkByMiko/';
__EXT__	= '.lua';

function LoadFramework:load(xmlFile)
end;

function LoadFramework:loadMap(name)
	source(Utils.getFilename("lua/init"..__EXT__, g_modsDirectory..__BASE_DIR__));
end;

function LoadFramework:deleteMap()	
end;

function LoadFramework:mouseEvent(posX, posY, isDown, isUp, button)
end;

function LoadFramework:keyEvent(unicode, sym, modifier, isDown)
end;

function LoadFramework:update(dt)
end;

function LoadFramework:draw()
end;

addModEventListener(LoadFramework);