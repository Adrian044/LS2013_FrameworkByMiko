-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- LS 2013 Framework by Miko 
-- Loader
------------------------------------------------------------*/

__BASE_DIR__ = '/__frameworkByMiko/';
__EXT__	= '.lua';

source(Utils.getFilename("lua/init"..__EXT__, g_modsDirectory..__BASE_DIR__));
InitFramework:load();